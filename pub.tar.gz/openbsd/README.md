# OpenBSD Infrastructure Automation

Complete Rails 8 deployment for OpenBSD.

**Quick Start:** `doas zsh openbsd.sh --pre-point`

See `openbsd.sh` for documentation.
